import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import AccessibilityMenu from './components/AccessibilityMenu';
import HomePage from './pages/HomePage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsOfUsePage from './pages/TermsOfUsePage';
import AccessibilityStatementPage from './pages/AccessibilityStatementPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-black text-white">
        <Routes>
          <Route
            path="/"
            element={
              <>
                <Navbar />
                <HomePage />
                <Footer />
                <AccessibilityMenu />
              </>
            }
          />
          <Route
            path="/privacy"
            element={
              <>
                <PrivacyPolicyPage />
                <AccessibilityMenu />
              </>
            }
          />
          <Route
            path="/terms"
            element={
              <>
                <TermsOfUsePage />
                <AccessibilityMenu />
              </>
            }
          />
          <Route
            path="/accessibility"
            element={
              <>
                <AccessibilityStatementPage />
                <AccessibilityMenu />
              </>
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
