import { Plus, Minus } from 'lucide-react';
import { useState } from 'react';

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: 'כמה זמן לוקח לפתח מערכת מידע?',
    answer: 'זמן הפיתוח משתנה בהתאם למורכבות המערכת והיקף הדרישות. פרויקט ממוצע נמשך בין 8-12 שבועות, אך מערכות פשוטות יכולות להיות מוכנות תוך 4-6 שבועות. נספק לכם לוח זמנים מדויק לאחר שלב האפיון.',
  },
  {
    question: 'כמה עולה לבנות מערכת מידע מותאמת?',
    answer: 'העלות תלויה בהיקף הפרויקט, מורכבות התהליכים ומספר המשתמשים. נציע הצעת מחיר מפורטת וברורה לאחר פגישת אפיון ראשונית. אנו מאמינים בשקיפות מלאה - המחיר כולל פיתוח, הטמעה, הדרכה ותמיכה ראשונית.',
  },
  {
    question: 'האם אתם מספקים אחריות ותמיכה?',
    answer: 'כן! אנו מעניקים אחריות מלאה על המערכת ותמיכה טכנית זמינה 24/7. כל בעיה או תקלה מטופלת במהירות. בנוסף, אנו מספקים עדכונים שוטפים, תחזוקה מתמשכת והתאמות לפי צרכים משתנים.',
  },
  {
    question: 'האם המערכת תתממשק למערכות הקיימות שלנו?',
    answer: 'בהחלט! אנו מתמחים באינטגרציות בין מערכות שונות. נוכל לחבר את המערכת החדשה למערכות קיימות כמו ERP, CRM, מערכות חשבונאות, אתרי אינטרנט ועוד. זה חלק מהליבה של השירות שלנו.',
  },
  {
    question: 'מה קורה אם נרצה להוסיף תכונות אחרי ההטמעה?',
    answer: 'אנו מתכננים את המערכת להיות גמישה ומודולרית. תוספות ושינויים הם חלק טבעי מהתפתחות העסק. כל בקשה לשינוי או תוספת מתועדת, נעריך את ההשפעה והעלות, ונבצע את השינויים בצורה מקצועית.',
  },
  {
    question: 'איך אתם מגנים על המידע והנתונים שלנו?',
    answer: 'אבטחת מידע היא בראש סדר העדיפויות שלנו. אנו משתמשים בהצפנה מתקדמת, גיבויים אוטומטיים, ניהול הרשאות מבוסס תפקידים ותקני אבטחה מובילים. כל הנתונים שלכם מאובטחים ומוגנים בצורה מקסימלית.',
  },
  {
    question: 'האם נצטרך ידע טכני כדי להפעיל את המערכת?',
    answer: 'בכלל לא! אנו מתכננים את כל המערכות להיות ידידותיות ואינטואיטיביות למשתמש. בנוסף, אנו מספקים הדרכה מקיפה לכל הצוות, מדריכי משתמש ותמיכה זמינה. המטרה היא שכל אחד יוכל להשתמש במערכת בקלות.',
  },
  {
    question: 'מה קורה אם נתקלים בבעיה או תקלה?',
    answer: 'יש לנו צוות תמיכה טכנית זמין 24/7 שמוכן לטפל בכל בעיה. ניתן ליצור קשר דרך טלפון, מייל או צ׳אט. רוב הבעיות נפתרות תוך שעות ספורות. בנוסף, אנו עושים הכל כדי למנוע בעיות מראש באמצעות ניטור ותחזוקה שוטפת.',
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="relative py-24 bg-black">
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-950 via-black to-zinc-950"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            שאלות נפוצות
          </h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">
            תשובות לשאלות שמעניינות אתכם
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="group bg-gradient-to-br from-zinc-900 to-zinc-950 border border-slate-800 rounded-xl overflow-hidden hover:border-amber-500/50 transition-all duration-300"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-5 flex items-center justify-between text-right hover:bg-zinc-900/50 transition-colors duration-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-amber-600 rounded-lg flex items-center justify-center flex-shrink-0">
                    {openIndex === index ? (
                      <Minus className="w-4 h-4 text-black" />
                    ) : (
                      <Plus className="w-4 h-4 text-black" />
                    )}
                  </div>
                </div>

                <h3 className="text-lg md:text-xl font-semibold text-white group-hover:text-amber-400 transition-colors">
                  {faq.question}
                </h3>
              </button>

              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="px-6 pb-5 pr-[4.5rem]">
                  <p className="text-slate-300 leading-relaxed text-right">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-slate-400 mb-4">
            לא מצאתם תשובה לשאלה שלכם?
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold rounded-lg hover:from-amber-400 hover:to-amber-500 transition-all duration-300 shadow-lg shadow-amber-500/20 hover:shadow-amber-500/40 hover:scale-105"
          >
            צרו קשר עכשיו
          </a>
        </div>
      </div>
    </section>
  );
}
