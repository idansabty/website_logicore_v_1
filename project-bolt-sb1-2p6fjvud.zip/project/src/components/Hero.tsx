import { ArrowLeft } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-zinc-950 via-zinc-900 to-black">
      <div className="absolute inset-0 w-full h-full">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-60"
        >
          <source src="/_users_8529cca2-33eb-41df-9198-50951c5c23c3_generated_0540f5a2-7a8f-4894-b160-475751d63416_generated_video.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-br from-black/40 via-zinc-900/50 to-black/40"></div>
      </div>

      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-64 h-64 bg-amber-500 blur-[120px]"></div>
        <div className="absolute bottom-20 right-20 w-64 h-64 bg-slate-400 blur-[120px]"></div>
      </div>

      <div className="hexagon-pattern absolute inset-0 opacity-5"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-block mb-6">
            <div className="flex items-center gap-2 bg-gradient-to-r from-amber-500/20 to-slate-400/20 px-6 py-2 rounded-full border border-amber-500/30">
              <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
              <span className="text-amber-400 text-sm font-medium">פתרונות מערכות מידע מתקדמים</span>
            </div>
          </div>

          <h1 className="text-6xl md:text-7xl lg:text-8xl font-bold mb-8 leading-tight">
            <span className="bg-gradient-to-l from-amber-400 via-amber-300 to-slate-300 bg-clip-text text-transparent">
              מהכאוס למערכת
            </span>
            <br />
            <span className="text-white">שעובדת בשבילך</span>
          </h1>

          <p className="text-xl md:text-2xl text-slate-300 mb-12 max-w-3xl mx-auto leading-relaxed">
            LogiCore מתמחה באפיון, בנייה והטמעה של מערכות מידע חכמות עבור עסקים קטנים ובינוניים.
            <span className="block mt-2 text-amber-400">הפכנו תהליכים מסורבלים למערכות אוטומטיות יעילות.</span>
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <a
              href="#contact"
              className="group relative px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-lg rounded-lg overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(245,158,11,0.5)] hover:scale-105 inline-block"
            >
              <span className="relative z-10 flex items-center gap-2">
                לתיאום פגישת אפיון חינם
                <ArrowLeft className="w-5 h-5 group-hover:translate-x-[-4px] transition-transform" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </a>

            <a
              href="#services"
              className="px-8 py-4 border-2 border-slate-400 text-slate-300 font-semibold text-lg rounded-lg hover:bg-slate-400/10 hover:border-amber-400 hover:text-amber-400 transition-all duration-300 inline-block"
            >
              למידע נוסף
            </a>
          </div>

          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { number: '50+', label: 'עסקים מרוצים' },
              { number: '100%', label: 'התאמה אישית' },
              { number: '24/7', label: 'תמיכה טכנית' }
            ].map((stat, idx) => (
              <div key={idx} className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-amber-500/20 to-slate-400/20 rounded-lg blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative bg-zinc-900/50 backdrop-blur-sm border border-slate-700 rounded-lg p-6 hover:border-amber-500/50 transition-all duration-300">
                  <div className="text-4xl font-bold bg-gradient-to-r from-amber-400 to-slate-300 bg-clip-text text-transparent mb-2">
                    {stat.number}
                  </div>
                  <div className="text-slate-400">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-slate-600 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-1.5 bg-amber-500 rounded-full"></div>
        </div>
      </div>
    </section>
  );
}
