const partners = [
  {
    name: 'Priority',
    logo: '/priority-1-3im4s84e4b0cr5fx5kxr7u.jpg',
  },
  {
    name: 'Salesforce',
    logo: '/images.png',
  },
  {
    name: 'Bolt',
    logo: '/הורדה.jpeg',
  },
  {
    name: 'Microsoft',
    logo: '/הורדה.png',
  },
];

export default function Partners() {
  return (
    <section className="relative py-20 bg-black overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-amber-500 opacity-5 blur-[150px] rounded-full"></div>
        <div className="absolute top-1/2 right-1/4 w-96 h-96 bg-slate-400 opacity-5 blur-[150px] rounded-full"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block mb-4">
              <span className="text-slate-400 font-semibold text-sm tracking-wider uppercase">שותפים עסקיים</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="text-white">עובדים עם</span>
              <br />
              <span className="bg-gradient-to-l from-amber-400 to-slate-300 bg-clip-text text-transparent">
                המובילים בתעשייה
              </span>
            </h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              אנחנו גאים לעבוד עם הטכנולוגיות והפלטפורמות המתקדמות ביותר
            </p>
          </div>

          <div className="relative">
            <div className="flex items-center justify-center gap-12 md:gap-16 flex-wrap">
              {partners.map((partner, idx) => (
                <div
                  key={idx}
                  className="group relative"
                  style={{
                    animation: `fadeInUp 0.8s ease-out ${idx * 0.15}s both`,
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-slate-400/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-xl"></div>

                  <div className="relative bg-zinc-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl p-8 hover:border-amber-500/40 transition-all duration-500 group-hover:scale-105 group-hover:shadow-2xl">
                    <div className="w-40 h-24 flex items-center justify-center">
                      <img
                        src={partner.logo}
                        alt={partner.name}
                        className="max-w-full max-h-full object-contain filter grayscale group-hover:grayscale-0 opacity-70 group-hover:opacity-100 transition-all duration-500"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-16 flex justify-center">
            <div className="inline-flex items-center gap-3 bg-zinc-900/30 backdrop-blur-sm border border-slate-800 rounded-full px-6 py-3">
              <div className="flex -space-x-2">
                <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full border-2 border-black flex items-center justify-center">
                  <span className="text-black text-xs font-bold">✓</span>
                </div>
                <div className="w-8 h-8 bg-gradient-to-br from-slate-400 to-slate-500 rounded-full border-2 border-black flex items-center justify-center">
                  <span className="text-black text-xs font-bold">✓</span>
                </div>
                <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full border-2 border-black flex items-center justify-center">
                  <span className="text-black text-xs font-bold">✓</span>
                </div>
              </div>
              <span className="text-slate-400 text-sm font-medium">שותפים מוסמכים וגאים</span>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
}
