import { Search, Lightbulb, Code, CheckCircle, Headphones } from 'lucide-react';

const steps = [
  {
    icon: Search,
    title: 'שלב 1: אפיון וייעוץ',
    description: 'נפגש איתך להבנת הצרכים העסקיים, ניתוח התהליכים הקיימים וזיהוי נקודות שיפור. נבנה ביחד מפה מדויקת של הדרישות.',
    duration: '1-2 שבועות',
    deliverables: ['מסמך דרישות מפורט', 'מפת תהליכים', 'הצעת מחיר מדויקת']
  },
  {
    icon: Lightbulb,
    title: 'שלב 2: תכנון ועיצוב',
    description: 'תכנון ארכיטקטורת המערכת, עיצוב ממשקי משתמש אינטואיטיביים ובניית אב טיפוס. נוודא שהפתרון מתאים בדיוק לצרכים שלך.',
    duration: '2-3 שבועות',
    deliverables: ['תרשימי זרימה', 'עיצובי UI/UX', 'אב טיפוס ראשוני']
  },
  {
    icon: Code,
    title: 'שלב 3: פיתוח ובנייה',
    description: 'פיתוח המערכת בשלבים, עם עדכונים שוטפים והצגת התקדמות. פיתוח זריז שמאפשר גמישות ושינויים תוך כדי תנועה.',
    duration: '4-8 שבועות',
    deliverables: ['גרסאות עבודה', 'בדיקות שוטפות', 'תיעוד טכני']
  },
  {
    icon: CheckCircle,
    title: 'שלב 4: הטמעה והדרכה',
    description: 'העלאה לסביבת הייצור, הדרכת הצוות שלך, העברת מידע מהמערכת הישנה ובדיקות קבלה מקיפות.',
    duration: '1-2 שבועות',
    deliverables: ['מערכת פעילה', 'הדרכות לצוות', 'מדריכי משתמש']
  },
  {
    icon: Headphones,
    title: 'שלב 5: תמיכה ושיפור',
    description: 'ליווי מתמשך, תמיכה טכנית זמינה, עדכונים שוטפים והתאמות בהתאם לצרכים המשתנים של העסק.',
    duration: 'מתמשך',
    deliverables: ['תמיכה 24/7', 'עדכונים חודשיים', 'שיפורים מתמשכים']
  }
];

export default function Process() {
  return (
    <section className="relative py-24 bg-black" id="process">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-zinc-900 via-black to-black"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-block mb-4">
            <span className="text-amber-500 font-semibold text-sm tracking-wider uppercase">תהליך העבודה</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="text-white">המסע שלנו</span>
            <br />
            <span className="bg-gradient-to-r from-slate-300 to-amber-400 bg-clip-text text-transparent">
              מרעיון למערכת חיה
            </span>
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            תהליך שקוף, מובנה ומקצועי שמבטיח תוצאות מעולות בכל פעם
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="relative">
            <div className="absolute right-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-amber-500 via-slate-400 to-amber-500 hidden md:block"></div>

            <div className="space-y-12">
              {steps.map((step, idx) => (
                <div
                  key={idx}
                  className="relative"
                >
                  <div className="flex flex-col md:flex-row gap-8 items-start">
                    <div className="flex-shrink-0 relative z-10">
                      <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/30 hover:scale-110 transition-transform duration-300">
                        <step.icon className="w-8 h-8 text-black" />
                      </div>
                    </div>

                    <div className="flex-1 group">
                      <div className="relative bg-gradient-to-br from-zinc-900 to-zinc-950 border border-slate-800 rounded-2xl p-8 hover:border-amber-500/50 transition-all duration-300">
                        <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-amber-500/10 to-transparent rounded-bl-[100px] rounded-tr-2xl"></div>

                        <div className="relative">
                          <div className="flex justify-between items-start mb-4">
                            <h3 className="text-2xl font-bold text-white group-hover:text-amber-400 transition-colors">
                              {step.title}
                            </h3>
                            <span className="text-sm text-slate-500 bg-slate-800/50 px-3 py-1 rounded-full">
                              {step.duration}
                            </span>
                          </div>

                          <p className="text-slate-400 mb-6 leading-relaxed">
                            {step.description}
                          </p>

                          <div>
                            <h4 className="text-sm font-semibold text-amber-400 mb-3">תוצרים:</h4>
                            <div className="flex flex-wrap gap-2">
                              {step.deliverables.map((deliverable, delIdx) => (
                                <span
                                  key={delIdx}
                                  className="text-sm bg-slate-800/50 text-slate-300 px-3 py-1 rounded-lg border border-slate-700"
                                >
                                  {deliverable}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-16 text-center">
            <div className="inline-block bg-gradient-to-r from-amber-500/10 to-slate-400/10 border border-amber-500/30 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-white mb-4">
                ⏱️ זמן יישום ממוצע: 8-12 שבועות
              </h3>
              <p className="text-slate-400">
                מהפגישה הראשונה ועד למערכת פעילה ומתפקדת
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
