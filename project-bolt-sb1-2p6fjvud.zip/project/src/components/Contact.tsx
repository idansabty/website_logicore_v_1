import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';
import { useState, FormEvent } from 'react';
import { supabase } from '../lib/supabase';
import emailjs from '@emailjs/browser';
import PrivacyPolicy from './PrivacyPolicy';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [agreedToPrivacy, setAgreedToPrivacy] = useState(false);
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!agreedToPrivacy) {
      setError('יש לאשר את מדיניות הפרטיות לפני שליחת הטופס');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const { error: dbError } = await supabase
        .from('contact_submissions')
        .insert([{
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          company: formData.company || '',
          message: formData.message
        }]);

      if (dbError) throw dbError;

      await emailjs.send(
        import.meta.env.VITE_EMAILJS_SERVICE_ID,
        import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
        {
          from_name: formData.name,
          from_email: formData.email,
          phone: formData.phone,
          company: formData.company,
          message: formData.message,
          to_email: 'idansabty@gmail.com'
        },
        import.meta.env.VITE_EMAILJS_PUBLIC_KEY
      );

      setIsSuccess(true);
      setFormData({ name: '', email: '', phone: '', company: '', message: '' });
      setAgreedToPrivacy(false);
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'אירעה שגיאה בשליחת הטופס');
      console.error('Error submitting form:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'טלפון',
      value: '052-506-0256',
      link: 'tel:0525060256'
    },
    {
      icon: Mail,
      title: 'אימייל',
      value: 'idansabty@gmail.com',
      link: 'mailto:idansabty@gmail.com'
    },
    {
      icon: MapPin,
      title: 'כתובת',
      value: 'ראשון לציון, ישראל',
      link: '#'
    }
  ];

  return (
    <section id="contact" className="relative py-24 bg-gradient-to-br from-zinc-950 via-zinc-900 to-black overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-40 right-40 w-96 h-96 bg-amber-500 blur-[150px]"></div>
        <div className="absolute bottom-40 left-40 w-96 h-96 bg-slate-400 blur-[150px]"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <div className="flex items-center gap-2 bg-gradient-to-r from-amber-500/20 to-slate-400/20 px-6 py-2 rounded-full border border-amber-500/30">
              <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
              <span className="text-amber-400 text-sm font-medium">צור קשר</span>
            </div>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-l from-amber-400 via-amber-300 to-slate-300 bg-clip-text text-transparent">
              בואו נדבר
            </span>
          </h2>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            נשמח לשמוע עליכם ועל האתגרים שלכם. השאירו פרטים ונחזור אליכם בהקדם.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="space-y-8">
            <div>
              <h3 className="text-3xl font-bold text-white mb-6">פרטי התקשרות</h3>
              <div className="space-y-6">
                {contactInfo.map((info, idx) => (
                  <a
                    key={idx}
                    href={info.link}
                    className="group flex items-start gap-4 p-6 bg-zinc-900/50 backdrop-blur-sm border border-slate-700 rounded-xl hover:border-amber-500/50 transition-all duration-300"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-amber-500/20 to-slate-400/20 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:from-amber-500/30 group-hover:to-slate-400/30 transition-all">
                      <info.icon className="w-6 h-6 text-amber-400" />
                    </div>
                    <div className="text-right">
                      <div className="text-slate-400 text-sm mb-1">{info.title}</div>
                      <div className="text-white font-medium text-lg group-hover:text-amber-400 transition-colors">
                        {info.value}
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-amber-500/20 to-slate-400/20 rounded-xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative bg-zinc-900/50 backdrop-blur-sm border border-slate-700 rounded-xl p-8">
                <h4 className="text-2xl font-bold text-white mb-4">שעות פעילות</h4>
                <div className="space-y-3 text-slate-300">
                  <div className="flex justify-between">
                    <span>ראשון - חמישי</span>
                    <span className="text-amber-400 font-medium">8:00 - 22:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>שישי</span>
                    <span className="text-amber-400 font-medium">8:00 - 22:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>שבת</span>
                    <span className="text-amber-400 font-medium">8:00 - 22:00</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="relative group">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500/10 to-slate-400/10 rounded-2xl blur-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative bg-zinc-900/50 backdrop-blur-sm border border-slate-700 rounded-2xl p-8">
              {isSuccess ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <CheckCircle className="w-20 h-20 text-green-500 mb-6" />
                  <h3 className="text-3xl font-bold text-white mb-4">הפנייה נשלחה בהצלחה!</h3>
                  <p className="text-slate-300 text-lg">נחזור אליכם בהקדם האפשרי</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {error && (
                    <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 text-red-400 text-right">
                      {error}
                    </div>
                  )}
                  <div>
                    <label htmlFor="name" className="block text-slate-300 mb-2 text-right font-medium">
                      שם מלא *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-zinc-800/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors text-right"
                      placeholder="הזן שם מלא"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-slate-300 mb-2 text-right font-medium">
                        אימייל *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-zinc-800/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors text-right"
                        placeholder="name@example.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-slate-300 mb-2 text-right font-medium">
                        טלפון *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 bg-zinc-800/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors text-right"
                        placeholder="050-1234567"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-slate-300 mb-2 text-right font-medium">
                      שם החברה
                    </label>
                    <input
                      type="text"
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-zinc-800/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors text-right"
                      placeholder="שם החברה (אופציונלי)"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-slate-300 mb-2 text-right font-medium">
                      הודעה *
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      value={formData.message}
                      onChange={handleChange}
                      rows={5}
                      className="w-full px-4 py-3 bg-zinc-800/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors resize-none text-right"
                      placeholder="ספר לנו על הפרויקט שלך..."
                    />
                  </div>

                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      id="privacy"
                      checked={agreedToPrivacy}
                      onChange={(e) => setAgreedToPrivacy(e.target.checked)}
                      className="mt-1 w-5 h-5 accent-amber-500 cursor-pointer"
                    />
                    <label htmlFor="privacy" className="text-slate-300 text-sm leading-relaxed cursor-pointer text-right flex-1">
                      קראתי ואני מאשר/ת את{' '}
                      <button
                        type="button"
                        onClick={() => setShowPrivacyPolicy(true)}
                        className="text-amber-400 hover:text-amber-300 underline font-semibold transition-colors"
                      >
                        מדיניות הפרטיות
                      </button>
                      {' '}ומסכים/ה לשמירה ולשימוש בפרטיי בהתאם למדיניות זו *
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="group relative w-full px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-lg rounded-lg overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(245,158,11,0.5)] hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span className="relative z-10 flex items-center justify-center gap-2">
                      {isSubmitting ? 'שולח...' : 'שלח פנייה'}
                      {!isSubmitting && <Send className="w-5 h-5 group-hover:translate-x-[-4px] transition-transform" />}
                    </span>
                    <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      <PrivacyPolicy isOpen={showPrivacyPolicy} onClose={() => setShowPrivacyPolicy(false)} />
    </section>
  );
}
