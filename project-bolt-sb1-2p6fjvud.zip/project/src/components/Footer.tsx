import { Mail, Phone, MapPin, Instagram } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-gradient-to-b from-black to-zinc-950 pt-20 pb-10">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500 to-transparent"></div>

      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          <div>
            <div className="mb-6">
              <h3 className="text-3xl font-bold bg-gradient-to-r from-amber-400 to-slate-300 bg-clip-text text-transparent">
                LogiCore
              </h3>
              <p className="text-slate-500 mt-2">Logic Meets Core Business</p>
            </div>
            <p className="text-slate-400 leading-relaxed">
              מתמחים באפיון, הטמעה ובנייה של מערכות מידע מתקדמות לעסקים קטנים ובינוניים.
            </p>
          </div>

          <div>
            <h4 className="text-white font-bold text-lg mb-6">צור קשר</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-slate-400 text-sm mb-1">אימייל</p>
                  <a href="mailto:idansabty@gmail.com" className="text-white hover:text-amber-400 transition-colors">
                    idansabty@gmail.com
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-slate-400 text-sm mb-1">טלפון</p>
                  <a href="tel:0525060256" className="text-white hover:text-amber-400 transition-colors" dir="ltr">
                    052-506-0256
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-amber-500 flex-shrink-0 mt-1" />
                <div>
                  <p className="text-slate-400 text-sm mb-1">כתובת</p>
                  <p className="text-white">
                    ראשון לציון, ישראל
                  </p>
                </div>
              </li>
            </ul>

            <div className="mt-6">
              <h5 className="text-white font-semibold mb-4">עקבו אחרינו</h5>
              <div className="flex gap-3">
                <a
                  href="https://www.instagram.com/logi.core1/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-slate-800 hover:bg-amber-500 rounded-lg flex items-center justify-center transition-all duration-300 hover:scale-110"
                >
                  <Instagram className="w-5 h-5 text-slate-400 hover:text-black transition-colors" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-sm">
              © {currentYear} LogiCore. כל הזכויות שמורות.
            </p>
            <div className="flex gap-6">
              <Link to="/terms" className="text-slate-500 hover:text-amber-400 text-sm transition-colors">
                תנאי שימוש
              </Link>
              <Link to="/privacy" className="text-slate-500 hover:text-amber-400 text-sm transition-colors">
                מדיניות פרטיות
              </Link>
              <Link to="/accessibility" className="text-slate-500 hover:text-amber-400 text-sm transition-colors">
                הצהרת נגישות
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
