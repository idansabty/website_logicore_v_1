import { useState, useEffect } from 'react';
import {
  Accessibility,
  X,
  ZoomIn,
  ZoomOut,
  Sun,
  Moon,
  Type,
  Mouse,
  Link as LinkIcon,
  RotateCcw
} from 'lucide-react';

interface AccessibilitySettings {
  fontSize: number;
  highContrast: boolean;
  highlightLinks: boolean;
  grayscale: boolean;
  invertColors: boolean;
  cursorSize: 'normal' | 'large' | 'extra-large';
}

const defaultSettings: AccessibilitySettings = {
  fontSize: 100,
  highContrast: false,
  highlightLinks: false,
  grayscale: false,
  invertColors: false,
  cursorSize: 'normal',
};

export default function AccessibilityMenu() {
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState<AccessibilitySettings>(defaultSettings);

  useEffect(() => {
    const savedSettings = localStorage.getItem('accessibilitySettings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('accessibilitySettings', JSON.stringify(settings));
    applySettings(settings);
  }, [settings]);

  const applySettings = (settings: AccessibilitySettings) => {
    const root = document.documentElement;

    root.style.fontSize = `${settings.fontSize}%`;

    if (settings.highContrast) {
      root.classList.add('high-contrast');
    } else {
      root.classList.remove('high-contrast');
    }

    if (settings.highlightLinks) {
      root.classList.add('highlight-links');
    } else {
      root.classList.remove('highlight-links');
    }

    if (settings.grayscale) {
      root.classList.add('grayscale');
    } else {
      root.classList.remove('grayscale');
    }

    if (settings.invertColors) {
      root.classList.add('invert-colors');
    } else {
      root.classList.remove('invert-colors');
    }

    root.classList.remove('cursor-normal', 'cursor-large', 'cursor-extra-large');
    root.classList.add(`cursor-${settings.cursorSize}`);
  };

  const updateSetting = <K extends keyof AccessibilitySettings>(
    key: K,
    value: AccessibilitySettings[K]
  ) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const resetSettings = () => {
    setSettings(defaultSettings);
  };

  const increaseFontSize = () => {
    setSettings(prev => ({
      ...prev,
      fontSize: Math.min(prev.fontSize + 10, 200)
    }));
  };

  const decreaseFontSize = () => {
    setSettings(prev => ({
      ...prev,
      fontSize: Math.max(prev.fontSize - 10, 80)
    }));
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 left-6 z-50 w-14 h-14 bg-gradient-to-br from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center group"
        aria-label="פתח תפריט נגישות"
      >
        <Accessibility className="w-6 h-6 group-hover:scale-110 transition-transform" />
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto border border-slate-800">
            <div className="sticky top-0 bg-gradient-to-r from-amber-500 to-amber-600 p-6 flex items-center justify-between z-10">
              <div className="flex items-center gap-3">
                <Accessibility className="w-6 h-6 text-white" />
                <h2 className="text-2xl font-bold text-white">תפריט נגישות</h2>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
                aria-label="סגור"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <div className="flex items-center gap-2 mb-4">
                  <Type className="w-5 h-5 text-amber-500" />
                  <h3 className="text-white font-semibold text-lg">גודל טקסט</h3>
                </div>
                <div className="flex items-center gap-4">
                  <button
                    onClick={decreaseFontSize}
                    className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                    disabled={settings.fontSize <= 80}
                  >
                    <ZoomOut className="w-5 h-5" />
                    <span>הקטן</span>
                  </button>
                  <span className="text-white font-bold min-w-[4rem] text-center">
                    {settings.fontSize}%
                  </span>
                  <button
                    onClick={increaseFontSize}
                    className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                    disabled={settings.fontSize >= 200}
                  >
                    <ZoomIn className="w-5 h-5" />
                    <span>הגדל</span>
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => updateSetting('highContrast', !settings.highContrast)}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    settings.highContrast
                      ? 'bg-amber-500 border-amber-500 text-white'
                      : 'bg-slate-800/50 border-slate-700 text-slate-300 hover:border-amber-500'
                  }`}
                >
                  <Sun className="w-5 h-5" />
                  <span className="font-semibold">ניגודיות גבוהה</span>
                </button>

                <button
                  onClick={() => updateSetting('highlightLinks', !settings.highlightLinks)}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    settings.highlightLinks
                      ? 'bg-amber-500 border-amber-500 text-white'
                      : 'bg-slate-800/50 border-slate-700 text-slate-300 hover:border-amber-500'
                  }`}
                >
                  <LinkIcon className="w-5 h-5" />
                  <span className="font-semibold">הדגשת קישורים</span>
                </button>

                <button
                  onClick={() => updateSetting('grayscale', !settings.grayscale)}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    settings.grayscale
                      ? 'bg-amber-500 border-amber-500 text-white'
                      : 'bg-slate-800/50 border-slate-700 text-slate-300 hover:border-amber-500'
                  }`}
                >
                  <Moon className="w-5 h-5" />
                  <span className="font-semibold">מצב אפור</span>
                </button>

                <button
                  onClick={() => updateSetting('invertColors', !settings.invertColors)}
                  className={`w-full p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                    settings.invertColors
                      ? 'bg-amber-500 border-amber-500 text-white'
                      : 'bg-slate-800/50 border-slate-700 text-slate-300 hover:border-amber-500'
                  }`}
                >
                  <Sun className="w-5 h-5" />
                  <span className="font-semibold">היפוך צבעים</span>
                </button>
              </div>

              <div className="bg-slate-800/50 rounded-xl p-4 border border-slate-700">
                <div className="flex items-center gap-2 mb-4">
                  <Mouse className="w-5 h-5 text-amber-500" />
                  <h3 className="text-white font-semibold text-lg">גודל סמן</h3>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  {(['normal', 'large', 'extra-large'] as const).map((size) => (
                    <button
                      key={size}
                      onClick={() => updateSetting('cursorSize', size)}
                      className={`py-3 px-4 rounded-lg transition-all font-semibold ${
                        settings.cursorSize === size
                          ? 'bg-amber-500 text-white'
                          : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                      }`}
                    >
                      {size === 'normal' && 'רגיל'}
                      {size === 'large' && 'גדול'}
                      {size === 'extra-large' && 'גדול מאוד'}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={resetSettings}
                className="w-full bg-gradient-to-r from-slate-700 to-slate-800 hover:from-slate-600 hover:to-slate-700 text-white py-4 px-6 rounded-xl transition-all flex items-center justify-center gap-2 font-semibold border border-slate-600"
              >
                <RotateCcw className="w-5 h-5" />
                <span>אפס להגדרות ברירת מחדל</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
