import { useState } from 'react';
import { Database, Workflow, Package, TrendingUp, Shield, Zap } from 'lucide-react';

const services = [
  {
    icon: Database,
    title: 'הטמעת מערכות מידע',
    description: 'פתרונות ERP, CRM ו-WMS מותאמים אישית שמתאימים בדיוק לצרכים העסקיים שלך. מערכות חכמות שצומחות איתך.',
    features: ['מערכות ERP מותאמות', 'CRM לניהול לקוחות', 'WMS לניהול מלאי'],
    fullContent: 'אנו מתמחים בהטמעה של מערכות מידע מודרניות המיועדות להנהלת העסק שלך. הפתרונות שלנו כוללים מערכות ERP מתאימות לתהליכים הייחודיים שלך, פלטפורמות CRM שיפעלו בשיתוף פעולה מינהלי עם הלקוחות שלך, ומערכות WMS שתנהלו את המלאי בצורה חכמה ויעילה. כל מערכת משולבת עם המערכות הקיימות שלך לתהליך חלק וללא הפרעות.'
  },
  {
    icon: Workflow,
    title: 'אוטומציה עסקית',
    description: 'הפיכת תהליכים ידניים לזרימות עבודה אוטומטיות. חיסכון בזמן, הפחתת טעויות והגברת היעילות העסקית.',
    features: ['זרימות עבודה אוטומטיות', 'אינטגרציות בין מערכות', 'דוחות אוטומטיים'],
    fullContent: 'אוטומציה עסקית היא המפתח להגדלת הרווחיות שלך. אנו מעצבים זרימות עבודה מורכבות המחליפות פעולות ידניות בהליכים אוטומטיים מהירים ודיוקיים. הדבר חוסך שעות עבודה חשובות וממנע טעויות אנוש. אנו משתמשים בטכנולוגיות מובילות לאינטגרציה בין כל מערכותיך, ויוצרים דוחות עדכניים שעוזרים לך לעקוב אחר תהליכים בזמן אמת.'
  },
  {
    icon: Package,
    title: 'ניהול מלאי ולוגיסטיקה',
    description: 'מערכות מתקדמות למעקב אחר מלאי, ניהול הזמנות ואופטימיזציה לוגיסטית. שליטה מלאה במלאי בזמן אמת.',
    features: ['מעקב מלאי בזמן אמת', 'ניהול הזמנות חכם', 'אופטימיזציה לוגיסטית'],
    fullContent: 'ניהול מלאי תקין הוא קריטי לעסק כל דורך. מערכות המלאי שלנו מספקות מעקב בזמן אמת, אפילו עם מחסנים מרובים ומיקומים גיאוגרפיים שונים. נהול ההזמנות החכם שלנו מוודא שאתה לעולם לא תחסר או תחסוך באופן יתר מוצרים. גם אופטימיזציה לוגיסטית משפרת את זמני המסירה ומוזילה את עלויות התובלה באופן משמעותי.'
  },
  {
    icon: TrendingUp,
    title: 'BI וניתוח נתונים',
    description: 'הפיכת נתונים לתובנות עסקיות. דשבורדים מתקדמים ודוחות חכמים שעוזרים לקבל החלטות מושכלות.',
    features: ['דשבורדים אינטראקטיביים', 'ניתוח נתונים מתקדם', 'תחזיות עסקיות'],
    fullContent: 'בעידן הנתונים, ההחלטות מבוססות על נתונים נמצאות בהישג יד. דשבורדים אינטראקטיביים שלנו מציגים KPIs חשובים בזמן אמת, המאפשרים לך לעקוב אחר ביצועי העסק במבט אחד. ניתוח נתונים מתקדם חושף דפוסים וטרנדים, בעוד תחזיות עסקיות מספקות תובנות לעתיד, עוזר לך לתכנן אסטרטגיות עסקיות חכמות.'
  },
  {
    icon: Shield,
    title: 'אבטחת מידע',
    description: 'הגנה מקסימלית על המידע העסקי שלך. יישום תקני אבטחה מובילים וגיבויים אוטומטיים.',
    features: ['הצפנת נתונים', 'גיבויים אוטומטיים', 'ניהול הרשאות'],
    fullContent: 'אבטחת מידע היא אחד מעמודי התווך של השירותים שלנו. אנו מיישמים הצפנה מתקדמת שמגנה על הנתונים שלך, וגיבויים אוטומטיים שמבטיחים שלעולם לא תאבד מידע חשוב. ניהול הרשאות מדוקדק משמר שרק אנשים מוסמכים יכולים לגשת למידע רגיש. תוכנו פטור מדיאגות בנוגע לאבטחת המידע שלך.'
  },
  {
    icon: Zap,
    title: 'תמיכה ואחזקה',
    description: 'ליווי מקצועי לאורך כל הדרך. תמיכה טכנית זמינה, עדכונים שוטפים והתאמות לצרכים המשתנים.',
    features: ['תמיכה 24/7', 'עדכונים שוטפים', 'שיפורים מתמשכים'],
    fullContent: 'לא מספיק רק להטמיע מערכת - אתה צריך תמיכה מתמשכת. צוות התמיכה שלנו זמין 24/7 כדי לעזור בכל שאלה או בעיה שעלולה להעלות. אנו מספקים עדכונים שוטפים לשמור על המערכות שלך מעודכנות ובטוחות, וגם מבצעים שיפורים מתמשכים על סמך המשוב שלך ודרישות העסק המשתנות.'
  }
];

export default function Services() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  return (
    <section className="relative py-24 bg-black" id="services">
      <div className="absolute inset-0 bg-gradient-to-b from-zinc-950 via-black to-zinc-950"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block mb-4">
            <span className="text-amber-500 font-semibold text-sm tracking-wider uppercase">השירותים שלנו</span>
          </div>
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-amber-400 to-slate-300 bg-clip-text text-transparent">
              פתרונות מלאים
            </span>
            <br />
            <span className="text-white">לכל צורך עסקי</span>
          </h2>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto">
            מערכות מידע מתקדמות שנבנו במיוחד עבור העסק שלך, עם התאמה מלאה לתהליכים הייחודיים שלך
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {services.map((service, idx) => (
            <div
              key={idx}
              className="group relative"
              style={{ animationDelay: `${idx * 100}ms` }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-slate-400/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500"></div>

              <div className="relative h-full bg-gradient-to-br from-zinc-900 to-zinc-950 border border-slate-800 rounded-2xl p-8 hover:border-amber-500/50 transition-all duration-300 flex flex-col">
                <div className="mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-amber-500/20">
                    <service.icon className="w-8 h-8 text-black" />
                  </div>
                </div>

                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-amber-400 transition-colors">
                  {service.title}
                </h3>

                <p className="text-slate-400 mb-6 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-3 mb-6">
                  {service.features.map((feature, featureIdx) => (
                    <li key={featureIdx} className="flex items-start gap-3">
                      <div className="w-1.5 h-1.5 bg-amber-500 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-slate-300 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                {expandedIndex === idx && (
                  <div className="mb-6 pt-6 border-t border-slate-700 max-h-64 overflow-y-auto">
                    <p className="text-slate-300 leading-relaxed">
                      {service.fullContent}
                    </p>
                  </div>
                )}

                <button
                  onClick={() => setExpandedIndex(expandedIndex === idx ? null : idx)}
                  className="mt-auto text-amber-400 hover:text-amber-300 font-semibold text-sm transition-colors flex items-center gap-2 group/btn"
                >
                  {expandedIndex === idx ? 'קרא פחות' : 'קרא עוד'}
                  <span className={`transition-transform duration-300 ${expandedIndex === idx ? 'rotate-180' : ''}`}>
                    ↓
                  </span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
