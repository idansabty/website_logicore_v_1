import { Target, Users, Rocket, Award, Clock, HeartHandshake } from 'lucide-react';

const reasons = [
  {
    icon: Target,
    title: 'פתרונות מותאמים אישית',
    description: 'לא מאמינים בפתרונות "one size fits all". כל מערכת שאנחנו בונים מותאמת במדויק לצרכים הייחודיים של העסק שלך.'
  },
  {
    icon: Users,
    title: 'התמחות בעסקים קטנים ובינוניים',
    description: 'אנחנו מבינים את האתגרים הספציפיים של עסקים בגודל שלך. פתרונות שמתאימים לתקציב ולהיקף הפעילות.'
  },
  {
    icon: Rocket,
    title: 'טכנולוגיה מתקדמת',
    description: 'שימוש בטכנולוגיות העדכניות ביותר בשוק. מערכות מהירות, אמינות ומאובטחות שצומחות עם העסק שלך.'
  },
  {
    icon: Award,
    title: 'ניסיון מוכח',
    description: 'למעלה מ-50 פרויקטים מוצלחים בתעשיות שונות. הניסיון שלנו מאפשר לנו להימנע ממלכודות נפוצות ולספק תוצאות מעולות.'
  },
  {
    icon: Clock,
    title: 'זמינות ותמיכה מלאה',
    description: 'תמיכה טכנית זמינה 24/7, עדכונים שוטפים והתאמות לצרכים המשתנים. אנחנו כאן בשבילך גם אחרי ההטמעה.'
  },
  {
    icon: HeartHandshake,
    title: 'ליווי אישי לאורך הדרך',
    description: 'ממפגש הייעוץ הראשון ועד ההטמעה המלאה - צוות מקצועי ייעודי שמלווה אותך בכל שלב.'
  }
];

export default function WhyUs() {
  return (
    <section className="relative py-24 bg-gradient-to-b from-zinc-950 to-black" id="why-us">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-amber-500 opacity-5 blur-[150px] rounded-full"></div>
        <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-slate-400 opacity-5 blur-[150px] rounded-full"></div>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block mb-4">
              <span className="text-slate-400 font-semibold text-sm tracking-wider uppercase">למה LogiCore?</span>
            </div>
            <h2 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="text-white">השותף שלך</span>
              <br />
              <span className="bg-gradient-to-l from-amber-400 to-slate-300 bg-clip-text text-transparent">
                להצלחה דיגיטלית
              </span>
            </h2>
            <p className="text-xl text-slate-400 max-w-3xl mx-auto">
              אנחנו לא רק ספק טכנולוגי - אנחנו שותף אסטרטגי שמחויב להצלחה שלך
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reasons.map((reason, idx) => (
              <div
                key={idx}
                className="group relative"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                <div className="relative h-full bg-zinc-900/30 backdrop-blur-sm border border-slate-800 rounded-2xl p-8 hover:border-amber-500/30 transition-all duration-300">
                  <div className="mb-6">
                    <div className="w-14 h-14 bg-gradient-to-br from-slate-700 to-slate-800 rounded-lg flex items-center justify-center group-hover:from-amber-500 group-hover:to-amber-600 transition-all duration-300 shadow-lg">
                      <reason.icon className="w-7 h-7 text-amber-400 group-hover:text-black transition-colors" />
                    </div>
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-amber-400 transition-colors">
                    {reason.title}
                  </h3>

                  <p className="text-slate-400 leading-relaxed">
                    {reason.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-20 text-center">
            <div className="inline-block bg-gradient-to-r from-zinc-900 to-zinc-950 border border-amber-500/30 rounded-2xl p-10 shadow-2xl">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-1 text-right">
                  <h3 className="text-3xl font-bold text-white mb-4">
                    מוכנים להתחיל?
                  </h3>
                  <p className="text-slate-400 text-lg mb-6">
                    בואו נדבר על איך נוכל לשדרג את העסק שלכם עם המערכת הנכונה
                  </p>
                  <a
                    href="#contact"
                    className="inline-block px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold text-lg rounded-lg hover:shadow-[0_0_30px_rgba(245,158,11,0.5)] hover:scale-105 transition-all duration-300"
                  >
                    קבעו פגישת ייעוץ חינם
                  </a>
                </div>
                <div className="w-px h-32 bg-gradient-to-b from-transparent via-slate-700 to-transparent hidden md:block"></div>
                <div className="flex-1 text-right">
                  <div className="space-y-4">
                    <div className="flex items-center justify-end gap-3">
                      <span className="text-slate-300 text-lg">תשובה תוך 24 שעות</span>
                      <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
                        <Clock className="w-5 h-5 text-amber-400" />
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-3">
                      <span className="text-slate-300 text-lg">ללא התחייבות</span>
                      <div className="w-10 h-10 bg-slate-400/20 rounded-lg flex items-center justify-center">
                        <HeartHandshake className="w-5 h-5 text-slate-400" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
