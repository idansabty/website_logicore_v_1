import { X, Shield } from 'lucide-react';

interface PrivacyPolicyProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PrivacyPolicy({ isOpen, onClose }: PrivacyPolicyProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-gradient-to-br from-zinc-900 to-black rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto border border-slate-800 my-8">
        <div className="sticky top-0 bg-gradient-to-r from-amber-500 to-amber-600 p-6 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-white" />
            <h2 className="text-2xl font-bold text-white">מדיניות פרטיות</h2>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            aria-label="סגור"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8 space-y-8 text-right">
          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">1. כללי</h3>
            <div className="text-slate-300 space-y-3 leading-relaxed">
              <p>אתר זה מופעל על ידי עידן סבטי (להלן: "מפעיל האתר").</p>
              <p>
                מפעיל האתר מכבד את פרטיות המשתמשים ופועל לשמירה על מידע אישי בהתאם להוראות הדין החל
                בישראל, ובפרט בהתאם ל־חוק הגנת הפרטיות ול־תקנות הגנת הפרטיות (אבטחת מידע).
              </p>
              <p className="font-semibold text-white">השימוש באתר מהווה הסכמה למדיניות פרטיות זו.</p>
            </div>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">2. סוגי מידע הנאספים</h3>

            <div className="mb-6">
              <h4 className="text-xl font-semibold text-white mb-3">א. מידע הנמסר ביוזמת המשתמש</h4>
              <p className="text-slate-300 mb-3">
                בעת השארת פרטים בטופס יצירת קשר או במסגרת התקשרות עסקית, עשוי להיאסף המידע הבא:
              </p>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li>שם מלא</li>
                <li>כתובת דוא"ל</li>
                <li>מספר טלפון</li>
                <li>פרטי עסק</li>
                <li>תוכן הפנייה</li>
              </ul>
            </div>

            <div>
              <h4 className="text-xl font-semibold text-white mb-3">ב. מידע טכני אוטומטי</h4>
              <p className="text-slate-300 mb-3">בעת השימוש באתר עשוי להיאסף מידע טכני כגון:</p>
              <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
                <li>כתובת IP</li>
                <li>סוג דפדפן ומכשיר</li>
                <li>נתוני גלישה והתנהגות באתר</li>
                <li>קובצי Cookies וכלי אנליטיקה</li>
              </ul>
            </div>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">3. מטרות השימוש במידע</h3>
            <p className="text-slate-300 mb-3">המידע נאסף ונעשה בו שימוש למטרות הבאות:</p>
            <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
              <li>מענה לפניות ומתן שירות</li>
              <li>יצירת קשר לצורך הצעת שירותים רלוונטיים</li>
              <li>שיפור חוויית המשתמש ותפקוד האתר</li>
              <li>עמידה בדרישות חוקיות</li>
              <li>משלוח דיוור שיווקי בכפוף להסכמה</li>
            </ul>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">4. דיוור ישיר והודעות שיווקיות</h3>
            <div className="text-slate-300 space-y-3 leading-relaxed">
              <p>
                שליחת מסרים שיווקיים תיעשה אך ורק לאחר קבלת הסכמה מפורשת ובהתאם להוראות חוק התקשורת
                (בזק ושידורים).
              </p>
              <p>ניתן לבטל הסכמה זו בכל עת באמצעות פנייה ישירה או קישור הסרה בהודעה.</p>
            </div>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">5. העברת מידע לצדדים שלישיים</h3>
            <p className="text-slate-300 mb-3">
              מפעיל האתר לא יעביר מידע אישי לצדדים שלישיים, למעט במקרים הבאים:
            </p>
            <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
              <li>ספקי שירות טכנולוגיים (אירוח, שירותי ענן, CRM, אנליטיקה)</li>
              <li>דרישה מכוח דין או צו שיפוטי</li>
              <li>מיזוג, מכירה או העברת פעילות עסקית</li>
            </ul>
            <p className="text-slate-300 mt-3">
              בכל מקרה, תינקטנה פעולות סבירות לשמירה על סודיות ואבטחת המידע.
            </p>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">6. אבטחת מידע</h3>
            <p className="text-slate-300 mb-3">
              האתר מיישם אמצעי אבטחה סבירים, בהתאם להוראות הדין, לרבות:
            </p>
            <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
              <li>שימוש בשרתים מאובטחים</li>
              <li>הגבלת הרשאות גישה למידע</li>
              <li>אמצעים טכנולוגיים להגנה מפני חדירה בלתי מורשית</li>
            </ul>
            <p className="text-slate-300 mt-3">
              עם זאת, אין ביכולת מפעיל האתר להבטיח חסינות מוחלטת מפני אירועי סייבר או גישה בלתי מורשית.
            </p>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">7. זכויות המשתמש</h3>
            <p className="text-slate-300 mb-3">בהתאם להוראות הדין, כל אדם זכאי:</p>
            <ul className="list-disc list-inside text-slate-300 space-y-2 mr-4">
              <li>לעיין במידע הנוגע אליו</li>
              <li>לבקש תיקון מידע שגוי או לא מעודכן</li>
              <li>לבקש מחיקה של מידע בכפוף להוראות הדין</li>
            </ul>
            <p className="text-slate-300 mt-3">
              לצורך מימוש זכויות אלו ניתן לפנות לכתובת:{' '}
              <a href="mailto:idansabty@gmail.com" className="text-amber-400 hover:underline">
                idansabty@gmail.com
              </a>
            </p>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">8. שימוש ב-Cookies</h3>
            <p className="text-slate-300">
              האתר עושה שימוש בקובצי Cookies לצורך תפעול תקין, ניתוח נתונים ושיפור חוויית המשתמש.
              ניתן לחסום או למחוק Cookies באמצעות הגדרות הדפדפן האישי.
            </p>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">9. שמירת מידע</h3>
            <p className="text-slate-300">
              המידע יישמר לפרק הזמן הנדרש לצורך מימוש מטרות האיסוף, או בהתאם לדרישות הדין החל.
            </p>
          </section>

          <section>
            <h3 className="text-2xl font-bold text-amber-400 mb-4">10. שינויים במדיניות</h3>
            <p className="text-slate-300 mb-3">
              מפעיל האתר רשאי לעדכן מדיניות זו מעת לעת, בהתאם לשינויים רגולטוריים, טכנולוגיים או עסקיים.
            </p>
            <p className="text-white font-semibold">תאריך עדכון אחרון: 16/02/2026</p>
          </section>
        </div>

        <div className="sticky bottom-0 bg-gradient-to-t from-zinc-900 to-transparent p-6 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold py-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(245,158,11,0.5)]"
          >
            סגור
          </button>
        </div>
      </div>
    </div>
  );
}
