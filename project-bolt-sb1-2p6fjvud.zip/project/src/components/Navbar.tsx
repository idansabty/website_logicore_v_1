import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { name: 'ראשי', href: '#' },
    { name: 'שירותים', href: '#services' },
    { name: 'למה אנחנו', href: '#why-us' },
    { name: 'תהליך', href: '#process' },
    { name: 'צור קשר', href: '#contact' }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-slate-800">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-32">
          <div className="flex items-center gap-3">
            <img
              src="/ChatGPT_Image_Feb_8,_2026,_01_17_14_PM.png"
              alt="LogiCore Logo"
              className="h-28 w-auto"
            />
          </div>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link, idx) => (
              <a
                key={idx}
                href={link.href}
                className="text-slate-300 hover:text-amber-400 transition-colors font-medium"
              >
                {link.name}
              </a>
            ))}
            <a
              href="#contact"
              className="px-6 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold rounded-lg hover:shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-all duration-300 inline-block"
            >
              בואו נדבר
            </a>
          </div>

          <button
            className="md:hidden text-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden pb-6">
            <div className="flex flex-col gap-4">
              {navLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.href}
                  className="text-slate-300 hover:text-amber-400 transition-colors font-medium py-2"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </a>
              ))}
              <a
                href="#contact"
                className="px-6 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-black font-bold rounded-lg mt-2 inline-block"
                onClick={() => setIsOpen(false)}
              >
                בואו נדבר
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
