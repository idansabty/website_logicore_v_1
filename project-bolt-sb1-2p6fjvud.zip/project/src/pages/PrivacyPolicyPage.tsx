import { Shield, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-black text-white">
      <div className="container mx-auto px-6 py-12">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 transition-colors mb-8"
        >
          <ArrowRight className="w-5 h-5" />
          <span>חזרה לדף הבית</span>
        </Link>

        <div className="max-w-4xl mx-auto bg-zinc-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <Shield className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white">מדיניות פרטיות</h1>
                <p className="text-white/90 mt-2">LogiCore - Logic Meets Core Business</p>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12 space-y-10 text-right">
            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                מבוא
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  ברוכים הבאים לאתר של LogiCore. אנו מכבדים ושומרים על פרטיות המשתמשים שלנו ופועלים בהתאם
                  להוראות חוק הגנת הפרטיות, התשמ"א-1981 ותקנות הגנת הפרטיות (אבטחת מידע), התשע"ז-2017.
                </p>
                <p>
                  מדיניות פרטיות זו מסבירה כיצד אנו אוספים, משתמשים ושומרים על המידע האישי שלך בעת שימוש
                  באתר שלנו. השימוש באתר מהווה הסכמה למדיניות פרטיות זו.
                </p>
                <p className="font-semibold text-white bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
                  מפעיל האתר: עידן סבטי | דוא"ל ליצירת קשר: idansabty@gmail.com
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                איסוף מידע
              </h2>

              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-semibold text-white mb-3">מידע שנמסר בהתנדבות</h3>
                  <p className="text-slate-300 mb-3 text-lg">
                    בעת מילוי טופס יצירת קשר או פנייה עסקית, אנו עשויים לאסוף את המידע הבא:
                  </p>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6 text-lg">
                    <li>שם מלא</li>
                    <li>כתובת דוא"ל</li>
                    <li>מספר טלפון</li>
                    <li>שם החברה (אופציונלי)</li>
                    <li>תוכן הפנייה והודעה</li>
                  </ul>
                  <div className="mt-4 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                    <p className="text-slate-300 text-lg">
                      <strong className="text-amber-400">שימו לב:</strong> מסירת מידע זה היא בהתנדבות מלאה. אין
                      חובה לספק מידע זה, אך ללא מידע מסוים לא נוכל לספק את השירות המבוקש.
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-2xl font-semibold text-white mb-3">מידע שנאסף באופן אוטומטי</h3>
                  <p className="text-slate-300 mb-3 text-lg">
                    בעת גלישה באתר, אנו עשויים לאסוף מידע טכני באופן אוטומטי, לרבות:
                  </p>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6 text-lg">
                    <li>כתובת IP (Internet Protocol)</li>
                    <li>סוג דפדפן ומערכת הפעלה</li>
                    <li>דפים שבהם ביקרת באתר ומשך הזמן של הביקור</li>
                    <li>מקור ההפניה (Referrer) שממנו הגעת לאתר</li>
                    <li>מידע על המכשיר (מובייל, טאבלט, מחשב)</li>
                  </ul>
                  <div className="mt-4 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                    <p className="text-slate-300 text-lg">
                      <strong className="text-amber-400">עוגיות (Cookies):</strong> האתר משתמש בעוגיות (Cookies)
                      לצורך שיפור חווית המשתמש ולמטרות אנליטיות. ניתן לחסום עוגיות באמצעות הגדרות הדפדפן, אך
                      זה עשוי להשפיע על תפקוד מסוימים של האתר.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                שימוש במידע
              </h2>
              <p className="text-slate-300 mb-4 text-lg">
                אנו משתמשים במידע שנאסף למטרות הבאות:
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <h4 className="font-semibold text-white mb-2 text-xl">תפעול האתר</h4>
                  <p className="text-slate-300">אספקת שירותים ותוכן מותאם אישית</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <h4 className="font-semibold text-white mb-2 text-xl">יצירת קשר</h4>
                  <p className="text-slate-300">מענה לפניות ושאלות שהתקבלו דרך טופס יצירת קשר</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <h4 className="font-semibold text-white mb-2 text-xl">שיפור השירות</h4>
                  <p className="text-slate-300">ניתוח ביצועים ושיפור חווית המשתמש</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <h4 className="font-semibold text-white mb-2 text-xl">חובות חוקיות</h4>
                  <p className="text-slate-300">עמידה בדרישות חוקיות ורגולטוריות</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <h4 className="font-semibold text-white mb-2 text-xl">שיווק</h4>
                  <p className="text-slate-300">משלוח עדכונים והצעות (בהסכמה מפורשת בלבד)</p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <h4 className="font-semibold text-white mb-2 text-xl">אבטחת מידע</h4>
                  <p className="text-slate-300">זיהוי ומניעת פעילות חשודה או תקלות</p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                אבטחת מידע במערכת
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אנו נוקטים באמצעי אבטחה פיזיים, טכנולוגיים וארגוניים סבירים להגנה על המידע האישי שלך מפני
                  גישה, שימוש, שינוי או חשיפה בלתי מורשים.
                </p>
                <div className="bg-gradient-to-r from-amber-500/10 to-slate-400/10 border border-amber-500/30 rounded-lg p-6">
                  <h4 className="font-semibold text-white mb-3 text-xl">אמצעי האבטחה שלנו כוללים:</h4>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6">
                    <li>הצפנת תעבורת נתונים באמצעות פרוטוקול SSL/TLS</li>
                    <li>שרתים מאובטחים עם הגבלות גישה</li>
                    <li>גיבוי קבוע של מידע</li>
                    <li>הגבלת גישה למידע רק לעובדים מורשים הנדרשים לשם מתן שירות</li>
                    <li>ניטור מערכות לזיהוי ומניעת חדירות</li>
                  </ul>
                </div>
                <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                  <p className="text-slate-300">
                    <strong className="text-red-400">חשוב לדעת:</strong> למרות מאמצינו, אין אמצעי אבטחה בעלי
                    חסינות מוחלטת. אנו לא יכולים להבטיח בטחון מוחלט של המידע, אך אנו ממשיכים לשפר באופן
                    שוטף את אמצעי האבטחה שלנו.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                זכויות המשתמש
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  בהתאם לחוק הגנת הפרטיות, לך כמשתמש מוקנות מספר זכויות בנוגע למידע האישי שלך:
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                    <div className="w-8 h-8 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-amber-400 font-bold">1</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">זכות עיון</h4>
                      <p className="text-slate-300">
                        הזכות לעיין במידע האישי שלך המצוי במאגר הנתונים שלנו
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                    <div className="w-8 h-8 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-amber-400 font-bold">2</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">זכות תיקון</h4>
                      <p className="text-slate-300">
                        הזכות לבקש תיקון או עדכון של מידע שגוי או לא מדויק
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                    <div className="w-8 h-8 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-amber-400 font-bold">3</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">זכות מחיקה</h4>
                      <p className="text-slate-300">
                        הזכות לבקש מחיקת המידע האישי שלך, בכפוף להוראות החוק
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-slate-800/50 border border-slate-700 rounded-lg p-4">
                    <div className="w-8 h-8 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <span className="text-amber-400 font-bold">4</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">זכות התנגדות</h4>
                      <p className="text-slate-300">
                        הזכות להתנגד לשימושים מסוימים במידע שלך, כולל דיוור שיווקי
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-500/50 rounded-lg p-6 mt-6">
                  <h4 className="font-semibold text-white mb-3 text-xl">איך מממשים את הזכויות?</h4>
                  <p className="text-slate-300 mb-3">
                    לצורך מימוש זכויותיך, ניתן לפנות אלינו בדרכים הבאות:
                  </p>
                  <div className="space-y-2">
                    <p className="text-white">
                      📧 דוא"ל:{' '}
                      <a href="mailto:idansabty@gmail.com" className="text-amber-400 hover:underline">
                        idansabty@gmail.com
                      </a>
                    </p>
                    <p className="text-white">
                      📱 טלפון:{' '}
                      <a href="tel:0525060256" className="text-amber-400 hover:underline" dir="ltr">
                        052-506-0256
                      </a>
                    </p>
                  </div>
                  <p className="text-slate-300 mt-3">
                    נשתדל להגיב לפנייתך בהקדם האפשרי ולא יאוחר מ-30 ימים מקבלת הפנייה.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                שיתוף מידע עם צדדים שלישיים
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אנו לא נמכור, נחכיר או נשתף את המידע האישי שלך עם צדדים שלישיים לצורכי שיווק ללא הסכמתך
                  המפורשת. אולם, אנו עשויים לשתף מידע במקרים הבאים:
                </p>
                <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6">
                  <li>
                    <strong className="text-white">ספקי שירות:</strong> חברות המספקות לנו שירותי אירוח,
                    אנליטיקה, דוא"ל ושירותים טכנולוגיים אחרים
                  </li>
                  <li>
                    <strong className="text-white">דרישה חוקית:</strong> כאשר נדרש על פי חוק, צו בית משפט או
                    הליך משפטי אחר
                  </li>
                  <li>
                    <strong className="text-white">הגנה על זכויות:</strong> כדי להגן על הזכויות, הרכוש או
                    הבטיחות שלנו, של המשתמשים או של הציבור
                  </li>
                </ul>
                <p className="text-slate-300">
                  כל ספקי השירות שלנו מחויבים חוזית לשמור על סודיות המידע ולהשתמש בו רק לצורכי מתן השירות
                  עבורנו.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                שמירת מידע
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אנו שומרים את המידע האישי שלך כל עוד הוא נדרש למטרות שלשמן נאסף, או בהתאם לדרישות החוק
                  החל בישראל.
                </p>
                <p>
                  לאחר שהמידע אינו נחוץ עוד, נמחק אותו או נבצע אנונימיזציה באופן מאובטח.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                קישורים לאתרים חיצוניים
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  האתר שלנו עשוי להכיל קישורים לאתרים חיצוניים. איננו אחראים למדיניות הפרטיות או לתוכן של
                  אתרים אלה. אנו ממליצים לקרוא את מדיניות הפרטיות של כל אתר חיצוני שאתה מבקר בו.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                שינויים במדיניות פרטיות
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אנו שומרים לעצמנו את הזכות לעדכן ולשנות מדיניות פרטיות זו מעת לעת, בהתאם לשינויים
                  טכנולוגיים, עסקיים או רגולטוריים.
                </p>
                <p>
                  במקרה של שינויים מהותיים, נפרסם הודעה באתר או נשלח הודעה בדוא"ל למשתמשים רשומים. המשך
                  השימוש באתר לאחר פרסום השינויים מהווה הסכמה למדיניות המעודכנת.
                </p>
              </div>
            </section>

            <section className="bg-gradient-to-r from-amber-500/10 to-slate-400/10 border border-amber-500/30 rounded-xl p-8">
              <h2 className="text-3xl font-bold text-white mb-4">יצירת קשר</h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אם יש לך שאלות, בקשות או חששות בנוגע למדיניות הפרטיות שלנו או לאופן שבו אנו מטפלים במידע
                  האישי שלך, אנא צור קשר:
                </p>
                <div className="bg-zinc-900/50 rounded-lg p-6 space-y-3">
                  <p className="text-white text-xl font-semibold">LogiCore</p>
                  <p className="text-white">
                    📧 דוא"ל:{' '}
                    <a href="mailto:idansabty@gmail.com" className="text-amber-400 hover:underline">
                      idansabty@gmail.com
                    </a>
                  </p>
                  <p className="text-white">
                    📱 טלפון:{' '}
                    <a href="tel:0525060256" className="text-amber-400 hover:underline" dir="ltr">
                      052-506-0256
                    </a>
                  </p>
                  <p className="text-white">📍 מיקום: ראשון לציון, ישראל</p>
                </div>
              </div>
            </section>

            <section className="border-t border-slate-700 pt-8">
              <p className="text-slate-400 text-center text-lg">
                <strong className="text-white">תאריך עדכון אחרון:</strong> 16 בפברואר 2026
              </p>
              <p className="text-slate-500 text-center mt-4">
                © 2026 LogiCore. כל הזכויות שמורות.
              </p>
            </section>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold px-8 py-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(245,158,11,0.5)] hover:scale-105"
          >
            <ArrowRight className="w-5 h-5" />
            <span>חזרה לדף הבית</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
