import { Eye, ArrowRight, CheckCircle, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AccessibilityStatementPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-black text-white">
      <div className="container mx-auto px-6 py-12">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 transition-colors mb-8"
        >
          <ArrowRight className="w-5 h-5" />
          <span>חזרה לדף הבית</span>
        </Link>

        <div className="max-w-4xl mx-auto bg-zinc-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-cyan-600 p-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <Eye className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white">הצהרת נגישות</h1>
                <p className="text-white/90 mt-2">LogiCore - מחויבות לנגישות דיגיטלית</p>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12 space-y-10 text-right">
            <section>
              <h2 className="text-3xl font-bold text-blue-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                מבוא
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <div className="bg-gradient-to-r from-blue-500/20 to-cyan-600/20 border border-blue-500/50 rounded-lg p-6">
                  <p className="text-white font-semibold text-xl mb-3">
                    ♿ מחויבות לנגישות
                  </p>
                  <p className="text-slate-300">
                    ב-LogiCore אנו מאמינים שכל אדם זכאי לגלוש באינטרנט באופן עצמאי, שוויוני ונגיש, ללא
                    קשר ליכולותיו הפיזיות או הטכנולוגיות. אנו רואים חשיבות עליונה במתן שירות שוויוני ונגיש
                    לכלל המשתמשים, לרבות אנשים עם מוגבלות.
                  </p>
                </div>
                <p>
                  השקענו מאמצים רבים כדי להפוך את האתר שלנו לנגיש ושמיש עבור כל המשתמשים. אנו ממשיכים
                  לפעול לשיפור רמת הנגישות באתר ולעמוד בהנחיות ובתקנים המקובלים בתחום הנגישות הדיגיטלית.
                </p>
                <p>
                  הצהרת נגישות זו חלה על אתר LogiCore הממוקם בכתובת:{' '}
                  <a href="https://logicore.co.il" className="text-blue-400 hover:underline font-semibold">
                    https://logicore.co.il
                  </a>
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-blue-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                פעולות שבוצעו להנגשת האתר
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  ביצענו מגוון פעולות מקיפות על מנת להנגיש את האתר ולהתאימו לשימוש נוח ושוויוני עבור כל
                  המשתמשים:
                </p>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">תאימות לדפדפנים</h3>
                        <p className="text-slate-300">
                          האתר מותאם לדפדפנים המודרניים כולל Chrome, Firefox, Safari ו-Edge
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">תצוגה רספונסיבית</h3>
                        <p className="text-slate-300">
                          האתר מותאם באופן מלא לשימוש במכשירים ניידים, טאבלטים ומחשבים שולחניים
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">תמיכה בקוראי מסך</h3>
                        <p className="text-slate-300">
                          האתר כולל תיוגי ARIA והגדרות סמנטיות המאפשרות שימוש בקוראי מסך כמו NVDA, JAWS
                          ו-VoiceOver
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">ניווט במקלדת</h3>
                        <p className="text-slate-300">
                          ניתן לנווט באתר באמצעות מקלדת בלבד, כולל מעבר בין רכיבים באמצעות מקש Tab
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">ניגודיות צבעים</h3>
                        <p className="text-slate-300">
                          שמירה על ניגודיות מספקת בין טקסט לרקע לשיפור הקריאות עבור אנשים עם לקות ראייה
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">גופנים קריאים</h3>
                        <p className="text-slate-300">
                          שימוש בגופנים ברורים וקריאים עם גדלים מתאימים לקריאה נוחה
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">תיוג תמונות</h3>
                        <p className="text-slate-300">
                          כל התמונות באתר מתויגות בטקסטים חלופיים (Alt Text) למשתמשי קוראי מסך
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">מבנה היררכי</h3>
                        <p className="text-slate-300">
                          שימוש בכותרות (Headings) בצורה היררכית ולוגית לניווט קל יותר בתוכן
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">קישורים ברורים</h3>
                        <p className="text-slate-300">
                          כל הקישורים באתר מתוארים בצורה ברורה ומובנת, עם אינדיקציות חזותיות למצב Focus
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">טפסים נגישים</h3>
                        <p className="text-slate-300">
                          טפסי יצירת קשר כולולים תיוגים ברורים והודעות שגיאה מפורטות
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">תפריט נגישות</h3>
                        <p className="text-slate-300">
                          האתר כולל תפריט נגישות ייעודי המאפשר התאמות אישיות כגון שינוי גודל גופן וניגודיות
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
                      <div>
                        <h3 className="text-white font-semibold mb-2">תמיכה ב-RTL</h3>
                        <p className="text-slate-300">
                          האתר מותאם במלואו לשפה העברית עם כיוון כתיבה מימין לשמאל (RTL)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-blue-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                רמת הנגישות
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-2xl font-semibold text-white mb-3 flex items-center gap-2">
                    ✓ תקן WCAG 2.1 - רמה AA
                  </h3>
                  <p className="text-slate-300 mb-3">
                    האתר הונגש בהתאם להנחיות התוכן הנגיש לאינטרנט (Web Content Accessibility Guidelines)
                    בגרסה 2.1, ברמת התאימות AA, ככל הניתן.
                  </p>
                  <p className="text-slate-300">
                    תקן WCAG 2.1 הוא תקן בינלאומי המפותח על ידי W3C (World Wide Web Consortium) ומגדיר
                    הנחיות להנגשת תכנים באינטרנט למגוון רחב של משתמשים עם מוגבלויות, כולל לקויות ראייה,
                    שמיעה, תנועה וקוגניציה.
                  </p>
                </div>

                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">עקרונות הנגישות (POUR)</h3>
                  <p className="text-slate-300 mb-4">תקן WCAG מבוסס על ארבעה עקרונות מרכזיים:</p>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">👁️</span>
                      <div>
                        <h4 className="text-white font-semibold">Perceivable (ניתן לתפיסה)</h4>
                        <p className="text-slate-400">המידע ורכיבי הממשק חייבים להיות מוצגים באופן שמשתמשים יכולים לתפוס</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">🖱️</span>
                      <div>
                        <h4 className="text-white font-semibold">Operable (ניתן להפעלה)</h4>
                        <p className="text-slate-400">רכיבי הממשק וניווט חייבים להיות ניתנים להפעלה</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">📖</span>
                      <div>
                        <h4 className="text-white font-semibold">Understandable (ניתן להבנה)</h4>
                        <p className="text-slate-400">המידע והפעלת הממשק חייבים להיות מובנים</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">💪</span>
                      <div>
                        <h4 className="text-white font-semibold">Robust (חסון)</h4>
                        <p className="text-slate-400">התוכן חייב להיות חסון מספיק כדי להתפרש על ידי מגוון רחב של סוכני משתמש</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">📋 תקנים ישראליים</h3>
                  <p className="text-slate-300">
                    הנגשת האתר בוצעה תוך התייחסות לתקנות שוויון זכויות לאנשים עם מוגבלות (התאמות נגישות
                    לשירות), התשע"ג-2013, ולתקן הישראלי (ת"י 5568) להנגשת אתרי אינטרנט.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-blue-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                טכנולוגיות מסייעות
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  האתר מותאם לעבודה עם הטכנולוגיות המסייעות הבאות:
                </p>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <h3 className="text-white font-semibold mb-2">🔊 קוראי מסך</h3>
                    <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                      <li>NVDA (Windows)</li>
                      <li>JAWS (Windows)</li>
                      <li>VoiceOver (macOS, iOS)</li>
                      <li>TalkBack (Android)</li>
                    </ul>
                  </div>
                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <h3 className="text-white font-semibold mb-2">⌨️ ניווט מקלדת</h3>
                    <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                      <li>מקש Tab - מעבר קדימה</li>
                      <li>Shift + Tab - מעבר אחורה</li>
                      <li>Enter - הפעלת קישורים וכפתורים</li>
                      <li>Escape - סגירת תפריטים</li>
                    </ul>
                  </div>
                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <h3 className="text-white font-semibold mb-2">🔍 הגדלת מסך</h3>
                    <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                      <li>ZoomText</li>
                      <li>Windows Magnifier</li>
                      <li>הגדלה במסך הדפדפן</li>
                    </ul>
                  </div>
                  <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                    <h3 className="text-white font-semibold mb-2">🎨 התאמות תצוגה</h3>
                    <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                      <li>מצב ניגודיות גבוהה</li>
                      <li>התאמת צבעים אישית</li>
                      <li>הגדלת גופנים</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-blue-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                מגבלות והחרגות
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  למרות מאמצינו להנגיש את כל העמודים והתכנים באתר, ייתכן שחלקים מסוימים עדיין אינם נגישים
                  במלואם. אנו ממשיכים לעבוד על שיפור הנגישות באופן שוטף.
                </p>
                <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">⚠️ תוכן מצד שלישי</h3>
                  <p className="text-slate-300">
                    האתר עשוי להכיל קישורים לאתרים חיצוניים או תכנים משובצים מצדדים שלישיים (כגון סרטוני
                    YouTube, מפות Google וכדומה). אנו אינם אחראים לנגישות של תכנים אלו, אולם אנו משתדלים
                    לבחור שירותים חיצוניים נגישים ככל הניתן.
                  </p>
                </div>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">📄 קבצים להורדה</h3>
                  <p className="text-slate-300">
                    מסמכים ותכנים להורדה (כגון קבצי PDF) עשויים לא להיות נגישים במלואם. במידה ונתקלתם
                    בקושי בגישה למסמך מסוים, אנא פנו אלינו ואנו נספק לכם גרסה נגישה או חלופה מתאימה.
                  </p>
                </div>
              </div>
            </section>

            <section className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-xl p-8">
              <h2 className="text-3xl font-bold text-white mb-6">נתקלתם בבעיית נגישות? אנחנו כאן לעזור</h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אם נתקלתם בבעיית נגישות כלשהי באתר, או אם אתם זקוקים לסיוע בשימוש בתכנים המוצגים בו,
                  אנו נשמח לעמוד לרשותכם. פנייתכם חשובה לנו ותסייע לנו לשפר את נגישות האתר עבור כלל
                  המשתמשים.
                </p>

                <div className="bg-zinc-900/50 rounded-lg p-6 space-y-4">
                  <h3 className="text-xl font-semibold text-white mb-4">דרכי יצירת קשר</h3>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold mb-2">דוא"ל</h4>
                      <a
                        href="mailto:idansabty@gmail.com"
                        className="text-blue-400 hover:text-blue-300 transition-colors text-lg"
                      >
                        idansabty@gmail.com
                      </a>
                      <p className="text-slate-400 text-sm mt-2">
                        נשתדל לחזור אליכם תוך 2-3 ימי עסקים
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h4 className="text-white font-semibold mb-2">טלפון</h4>
                      <a
                        href="tel:0525060256"
                        className="text-blue-400 hover:text-blue-300 transition-colors text-lg"
                        dir="ltr"
                      >
                        052-506-0256
                      </a>
                      <p className="text-slate-400 text-sm mt-2">
                        ניתן להשאיר הודעה ונחזור אליכם בהקדם
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">💡 מידע שימושי לפנייה</h3>
                  <p className="text-slate-300 mb-3">כדי לעזור לנו לטפל בפנייתכם בצורה היעילה ביותר, אנא צרפו:</p>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6">
                    <li>תיאור מפורט של הבעיה שנתקלתם בה</li>
                    <li>כתובת העמוד הספציפי באתר (URL)</li>
                    <li>הדפדפן והמכשיר בהם השתמשתם</li>
                    <li>פרטי הטכנולוגיה המסייעת בה אתם משתמשים (אם רלוונטי)</li>
                    <li>צילום מסך של הבעיה (אם אפשרי)</li>
                  </ul>
                </div>

                <p className="text-slate-400 italic">
                  אנו מתחייבים לטפל בכל פניה בהקדם האפשרי ולספק פתרון או חלופה נגישה למידע המבוקש.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-blue-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-blue-500 rounded-full"></span>
                שיפור מתמיד
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אנו רואים בנגישות ערך מרכזי ומתחייבים לשיפור מתמיד של רמת הנגישות באתר. אנו מבצעים
                  באופן קבוע:
                </p>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                  <ul className="list-disc list-inside text-slate-300 space-y-3 mr-6">
                    <li>בדיקות נגישות תקופתיות באמצעות כלים אוטומטיים וידניים</li>
                    <li>בדיקות עם משתמשים עם מוגבלויות</li>
                    <li>עדכון האתר בהתאם לתקנים ולטכנולוגיות המתפתחות</li>
                    <li>הדרכת צוות הפיתוח שלנו בנושאי נגישות</li>
                    <li>מעקב אחר משוב ופניות מצד משתמשים</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="border-t border-slate-700 pt-8">
              <div className="bg-gradient-to-r from-slate-800/50 to-slate-700/50 border border-slate-600 rounded-lg p-6">
                <h3 className="text-xl font-semibold text-white mb-3">📅 תאריך עדכון אחרון</h3>
                <p className="text-slate-300 text-lg">
                  הצהרת נגישות זו עודכנה לאחרונה ביום <strong className="text-white">16 בפברואר 2026</strong>
                </p>
                <p className="text-slate-400 mt-3">
                  אנו מעדכנים הצהרה זו באופן תקופתי על מנת לשקף שינויים ושיפורים שמתבצעים באתר.
                </p>
              </div>
            </section>

            <section className="border-t border-slate-700 pt-8">
              <p className="text-slate-500 text-center">
                © 2026 LogiCore. כל הזכויות שמורות.
              </p>
              <p className="text-slate-600 text-center mt-2 text-sm">
                אנו מחויבים ליצירת חוויית משתמש נגישה ושוויונית לכולם
              </p>
            </section>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white font-bold px-8 py-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(59,130,246,0.5)] hover:scale-105"
          >
            <ArrowRight className="w-5 h-5" />
            <span>חזרה לדף הבית</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
