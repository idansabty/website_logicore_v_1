import { Scale, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function TermsOfUsePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-zinc-900 to-black text-white">
      <div className="container mx-auto px-6 py-12">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 transition-colors mb-8"
        >
          <ArrowRight className="w-5 h-5" />
          <span>חזרה לדף הבית</span>
        </Link>

        <div className="max-w-4xl mx-auto bg-zinc-900/50 backdrop-blur-sm border border-slate-800 rounded-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <Scale className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white">תנאי שימוש</h1>
                <p className="text-white/90 mt-2">LogiCore - Logic Meets Core Business</p>
              </div>
            </div>
          </div>

          <div className="p-8 md:p-12 space-y-10 text-right">
            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                כללי
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  ברוכים הבאים לאתר LogiCore (להלן: "האתר"). תנאי שימוש אלו ("התנאים") מסדירים את השימוש
                  שלך באתר ובשירותים המוצעים בו.
                </p>
                <div className="bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-500/50 rounded-lg p-6">
                  <p className="text-white font-semibold text-xl mb-3">
                    ⚠️ חשוב לקרוא בעיון
                  </p>
                  <p className="text-slate-300">
                    השימוש באתר זה מהווה הסכמה מלאה ובלתי מסויגת לתנאים אלו. אם אינך מסכים לתנאים אלו,
                    אנא הימנע משימוש באתר.
                  </p>
                </div>
                <p>
                  מפעיל האתר: <strong className="text-white">עידן סבטי</strong>
                  <br />
                  דוא"ל:{' '}
                  <a href="mailto:idansabty@gmail.com" className="text-amber-400 hover:underline">
                    idansabty@gmail.com
                  </a>
                  <br />
                  טלפון:{' '}
                  <a href="tel:0525060256" className="text-amber-400 hover:underline" dir="ltr">
                    052-506-0256
                  </a>
                </p>
                <p>
                  אנו שומרים לעצמנו את הזכות לשנות, לעדכן או לתקן תנאים אלו בכל עת וללא הודעה מוקדמת. המשך
                  השימוש באתר לאחר ביצוע שינויים מהווה הסכמה לתנאים המעודכנים.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                קניין רוחני וזכויות יוצרים
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  כל התכנים המופיעים באתר, לרבות אך לא רק טקסטים, גרפיקה, לוגואים, אייקונים, תמונות, קבצי
                  אודיו, קבצי וידאו, עיצוב האתר, קוד מקור, קוד תוכנה ותכנים אחרים (להלן: "התכנים") הם
                  קניינו הבלעדי של LogiCore או של צדדים שלישיים שהעניקו לנו רישיון שימוש, והם מוגנים על פי
                  חוקי זכויות יוצרים, סימני מסחר וקניין רוחני בישראל ובעולם.
                </p>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 space-y-4">
                  <h3 className="text-xl font-semibold text-white">הגבלות שימוש</h3>
                  <p className="text-slate-300">
                    אין להעתיק, לשכפל, להפיץ, למכור, לשווק, להשכיר, להעביר, להציג בפומבי, לשדר, לשנות,
                    ליצור יצירות נגזרות מהתכנים או לעשות כל שימוש מסחרי או ציבורי בתכנים ללא קבלת אישור
                    מפורש בכתב מאיתנו מראש.
                  </p>
                  <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
                    <p className="text-slate-300">
                      <strong className="text-red-400">אזהרה:</strong> הפרת זכויות קניין רוחני מהווה עבירה
                      פלילית ואזרחית לפי החוק הישראלי ועלולה לגרור תביעות משפטיות ופיצויים כספיים.
                    </p>
                  </div>
                </div>
                <p>
                  שם "LogiCore", הלוגו והסימנים המסחריים האחרים המופיעים באתר הם סימנים רשומים או בלתי
                  רשומים של LogiCore. אין להשתמש בסימנים אלו ללא אישור בכתב מראש.
                </p>
                <div className="bg-gradient-to-r from-amber-500/10 to-slate-400/10 border border-amber-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">שימוש מותר</h3>
                  <p className="text-slate-300">
                    מותר לך לצפות בתכנים באתר למטרות אישיות ולא מסחריות בלבד, ולהדפיס עותקים בודדים של
                    דפים באתר לשימוש אישי בלבד, ובלבד שלא תמחק או תשנה הודעות זכויות יוצרים, סימני מסחר
                    או הודעות קנייניות אחרות.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                הגבלת אחריות
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <div className="bg-red-500/20 border-2 border-red-500/50 rounded-xl p-6">
                  <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    ⚠️ סעיף קריטי - אנא קרא בעיון
                  </h3>
                  <p className="text-white font-semibold mb-3">
                    השימוש באתר ובכל המידע והתכנים המופיעים בו הוא על אחריותך הבלעדית ומסופק על בסיס "כמות
                    שהוא" (AS-IS) ו-"כפי שזמין" (AS-AVAILABLE).
                  </p>
                </div>

                <div className="space-y-4">
                  <h3 className="text-2xl font-semibold text-white">אנו לא מתחייבים ולא מבטיחים כי:</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                      <p className="text-slate-300">
                        ✗ האתר יהיה זמין באופן רצוף וללא הפרעות
                      </p>
                    </div>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                      <p className="text-slate-300">
                        ✗ האתר יהיה נקי מתקלות, באגים או וירוסים
                      </p>
                    </div>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                      <p className="text-slate-300">
                        ✗ המידע באתר יהיה מדויק, מלא, עדכני או מהימן
                      </p>
                    </div>
                    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                      <p className="text-slate-300">
                        ✗ התוצאות שיתקבלו משימוש באתר יהיו מדויקות או אמינות
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border border-orange-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">כתב ויתור על אחריות</h3>
                  <p className="text-slate-300 mb-3">
                    LogiCore, מפעיליו, עובדיו, שותפיו, ספקיו ונותני רישיונות אינם אחראים בכל דרך שהיא,
                    במישרין או בעקיפין, לכל נזק מכל סוג שהוא (לרבות אך לא רק):
                  </p>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6">
                    <li>נזקים ישירים, עקיפים, מקריים, תוצאתיים או עונשיים</li>
                    <li>אובדן רווחים, הכנסות, נתונים או מידע</li>
                    <li>הפסקת עסקים או אובדן הזדמנויות עסקיות</li>
                    <li>נזק לרכוש או למוניטין</li>
                    <li>נזקים הנובעים מטעויות, אי דיוקים או השמטות בתכנים</li>
                    <li>נזקים שנגרמו כתוצאה מהסתמכות על מידע המופיע באתר</li>
                    <li>נזקים הנובעים מכשלים טכניים, תקלות או הפסקות בשירות</li>
                  </ul>
                </div>

                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">מערכות מידע עסקיות</h3>
                  <p className="text-slate-300">
                    בהקשר של מערכות מידע עסקיות (ERP, CRM, WMS וכדומה): המידע, הייעוץ והמלצות המוצגים
                    באתר הם למטרות מידע כללי בלבד ואינם מהווים ייעוץ מקצועי, משפטי, פיננסי או עסקי. אין
                    להסתמך על מידע זה לצורך קבלת החלטות עסקיות מבלי להתייעץ עם יועצים מקצועיים מתאימים.
                  </p>
                </div>

                <p className="text-slate-400 italic">
                  אחריותך הבלעדית ותרופתך היחידה בגין אי שביעות רצון מהאתר היא להפסיק את השימוש בו.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                שימוש הולם באתר
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  בעת שימוש באתר, אתה מתחייב לפעול בהתאם לכללים ולהנחיות הבאים:
                </p>

                <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3 flex items-center gap-2">
                    ✓ פעולות מותרות
                  </h3>
                  <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6">
                    <li>גלישה באתר למטרות אישיות ולא מסחריות</li>
                    <li>שליחת פניות לגיטימיות דרך טפסי יצירת קשר</li>
                    <li>קריאת התכנים והשירותים המוצעים</li>
                    <li>שיתוף קישורים לאתר ברשתות החברתיות (בהקשר הולם)</li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-red-500/10 to-rose-500/10 border border-red-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3 flex items-center gap-2">
                    ✗ פעולות אסורות
                  </h3>
                  <p className="text-slate-300 mb-3">
                    <strong>אתה מתחייב שלא לבצע את הפעולות הבאות:</strong>
                  </p>
                  <div className="space-y-3">
                    <div className="bg-slate-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-red-400 mb-2">פעולות תקיפה ואבטחה</h4>
                      <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                        <li>ניסיונות פריצה, האקינג או גישה לא מורשית למערכות האתר</li>
                        <li>סריקת פרצות אבטחה, בדיקות חדירה או ניצול חולשות</li>
                        <li>שימוש בכלים אוטומטיים (בוטים, סקריפטים, רובוטים) ללא אישור</li>
                        <li>העלאת וירוסים, תוכנות זדוניות (malware) או קוד מזיק</li>
                        <li>ניסיון לשבש, להעמיס יתר על המידה או לפגוע בתפקוד האתר (DDoS, DoS)</li>
                      </ul>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-red-400 mb-2">העתקה וקניין רוחני</h4>
                      <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                        <li>העתקה, שכפול או הפצה של קוד מקור, עיצוב או תכנים מהאתר</li>
                        <li>ביצוע הנדסה הפוכה (reverse engineering) של האתר או השירותים</li>
                        <li>יצירת יצירות נגזרות מהתכנים או השירותים</li>
                        <li>הסרה או שינוי של הודעות זכויות יוצרים וסימני מסחר</li>
                      </ul>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-red-400 mb-2">שימוש לרעה במערכת</h4>
                      <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                        <li>שליחת ספאם, דיוור המוני או תכנים פוגעניים</li>
                        <li>התחזות לאדם או גוף אחר</li>
                        <li>איסוף או שאיבת מידע באמצעים אוטומטיים (scraping, crawling)</li>
                        <li>שימוש באתר לכל מטרה בלתי חוקית או לא מוסרית</li>
                        <li>הפרעה לחווית משתמשים אחרים או פגיעה בהם</li>
                      </ul>
                    </div>

                    <div className="bg-slate-900/50 rounded-lg p-4">
                      <h4 className="font-semibold text-red-400 mb-2">פעילות מסחרית לא מורשית</h4>
                      <ul className="list-disc list-inside text-slate-300 space-y-1 mr-6">
                        <li>שימוש באתר למטרות מסחריות ללא אישור מפורש</li>
                        <li>מכירה, השכרה או העברת זכויות גישה לאתר</li>
                        <li>פרסום או שיווק של מוצרים או שירותים של צדדים שלישיים</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-500/20 border-2 border-orange-500/50 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">⚖️ תוצאות הפרת תנאי השימוש</h3>
                  <p className="text-slate-300">
                    הפרה של תנאי שימוש אלו עלולה לגרום לביטול מיידי של זכות הגישה שלך לאתר, לנקיטת הליכים
                    משפטיים אזרחיים ופליליים, ולתביעות נזיקין ופיצויים. אנו שומרים לעצמנו את הזכות לדווח על
                    פעילות חשודה או בלתי חוקית לרשויות אכיפת החוק.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                קישורים לאתרים חיצוניים
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  האתר עשוי להכיל קישורים לאתרים חיצוניים של צדדים שלישיים. קישורים אלו מסופקים לנוחיותך
                  בלבד.
                </p>
                <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <p className="text-slate-300">
                    אין לנו שליטה על תכנים, מדיניות הפרטיות או נהלים של אתרים חיצוניים אלה, ואיננו אחראים
                    לתכנים, לשירותים או לכל היבט אחר של אתרים אלה. הכללת קישור אינה מהווה אישור, תמיכה או
                    המלצה מצידנו. השימוש באתרים חיצוניים הוא על אחריותך הבלעדית.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                שיפוי
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אתה מסכים לשפות, להגן ולפטור את LogiCore, מפעיליו, עובדיו, נציגיו, שותפיו וספקיו מכל
                  תביעה, דרישה, הפסד, נזק, אחריות, עלות והוצאה (לרבות שכר טרחת עורכי דין) הנובעים מ:
                </p>
                <ul className="list-disc list-inside text-slate-300 space-y-2 mr-6 bg-slate-800/50 border border-slate-700 rounded-lg p-5">
                  <li>השימוש שלך באתר או הסתמכות על תכנים באתר</li>
                  <li>הפרה שלך של תנאי שימוש אלו</li>
                  <li>הפרה שלך של זכויות צד שלישי, לרבות זכויות קניין רוחני</li>
                  <li>כל תוכן או מידע שהעלית, שלחת או העברת דרך האתר</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                סמכות שיפוט והדין החל
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">הדין החל</h3>
                  <p className="text-slate-300">
                    תנאי שימוש אלו, כל שימוש באתר וכל סכסוך הנובע מהם או הקשור אליהם יהיו כפופים לדין
                    המהותי של מדינת ישראל בלבד, ללא תחולת כללי ברירת הדין שלו.
                  </p>
                </div>

                <div className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-white mb-3">סמכות שיפוט ייחודית</h3>
                  <p className="text-slate-300 mb-3">
                    סמכות השיפוט הבלעדית והייחודית בכל עניין הנוגע לאתר, לשירותים ולתנאי שימוש אלו תהיה
                    נתונה לבתי המשפט המוסמכים במחוז תל אביב-יפו בלבד.
                  </p>
                  <p className="text-slate-300">
                    השימוש באתר מהווה הסכמה בלתי חוזרת לסמכות השיפוט הייחודית של בתי משפט אלו ולוויתור על
                    כל טענה של חוסר סמכות עניינית או מקומית.
                  </p>
                </div>

                <p className="text-slate-400 italic">
                  האמור בתנאי שימוש אלו לא יפגע בזכויותינו לפנות לבית משפט מוסמך בכל מקום בעולם לצורך קבלת
                  סעד זמני או סעד אחר לשם הגנה על זכויות הקניין הרוחני שלנו או על אינטרסים לגיטימיים
                  אחרים.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                הפרדה ושארות
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אם יקבע על ידי בית משפט מוסמך כי הוראה כלשהי בתנאי שימוש אלו אינה תקפה, בלתי חוקית או
                  בלתי אכיפה, הוראה זו תבוטל או תוגבל במידה המינימלית הדרושה, ושאר ההוראות יישארו בתוקף
                  מלא.
                </p>
                <p>
                  אי אכיפה או אי שימוש של LogiCore בזכות או בהוראה כלשהי בתנאי שימוש אלו לא יהווה ויתור על
                  זכות או הוראה זו.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-bold text-amber-400 mb-4 flex items-center gap-3">
                <span className="w-2 h-8 bg-amber-500 rounded-full"></span>
                הסכם מלא
              </h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  תנאי שימוש אלו, יחד עם{' '}
                  <Link to="/privacy" className="text-amber-400 hover:underline font-semibold">
                    מדיניות הפרטיות
                  </Link>{' '}
                  שלנו, מהווים את ההסכם המלא והבלעדי בינך לבין LogiCore בנוגע לשימוש באתר, ומבטלים את כל
                  ההבנות, ההסכמים וההצהרות הקודמים והבו-זמניים, בין בכתב ובין בעל פה.
                </p>
              </div>
            </section>

            <section className="bg-gradient-to-r from-amber-500/10 to-slate-400/10 border border-amber-500/30 rounded-xl p-8">
              <h2 className="text-3xl font-bold text-white mb-4">יצירת קשר</h2>
              <div className="text-slate-300 space-y-4 leading-relaxed text-lg">
                <p>
                  אם יש לך שאלות, הבהרות או בקשות בנוגע לתנאי שימוש אלו, אנא צור קשר:
                </p>
                <div className="bg-zinc-900/50 rounded-lg p-6 space-y-3">
                  <p className="text-white text-xl font-semibold">LogiCore</p>
                  <p className="text-white">
                    📧 דוא"ל:{' '}
                    <a href="mailto:idansabty@gmail.com" className="text-amber-400 hover:underline">
                      idansabty@gmail.com
                    </a>
                  </p>
                  <p className="text-white">
                    📱 טלפון:{' '}
                    <a href="tel:0525060256" className="text-amber-400 hover:underline" dir="ltr">
                      052-506-0256
                    </a>
                  </p>
                  <p className="text-white">📍 מיקום: ראשון לציון, ישראל</p>
                </div>
              </div>
            </section>

            <section className="border-t border-slate-700 pt-8">
              <p className="text-slate-400 text-center text-lg">
                <strong className="text-white">תאריך עדכון אחרון:</strong> 16 בפברואר 2026
              </p>
              <p className="text-slate-500 text-center mt-4">
                © 2026 LogiCore. כל הזכויות שמורות.
              </p>
            </section>
          </div>
        </div>

        <div className="text-center mt-12">
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold px-8 py-4 rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(245,158,11,0.5)] hover:scale-105"
          >
            <ArrowRight className="w-5 h-5" />
            <span>חזרה לדף הבית</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
