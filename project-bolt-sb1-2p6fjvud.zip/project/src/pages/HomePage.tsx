import Hero from '../components/Hero';
import Services from '../components/Services';
import WhyUs from '../components/WhyUs';
import Partners from '../components/Partners';
import Process from '../components/Process';
import FAQ from '../components/FAQ';
import Contact from '../components/Contact';

export default function HomePage() {
  return (
    <>
      <Hero />
      <Services />
      <WhyUs />
      <Partners />
      <Process />
      <FAQ />
      <Contact />
    </>
  );
}
